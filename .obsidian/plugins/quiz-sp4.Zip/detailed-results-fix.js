// 퀴즈 상세 기록 화면 수정 (추가/삭제 버튼 제거, 불러오기 개선)

// showDetailedResults 함수에서 다음 부분을 찾아서:
// headerRow.createEl('th', { text: '추가', ... });
// headerRow.createEl('th', { text: '삭제', ... });
// 이 두 줄을 삭제

// 그리고 tbody의 각 row에서:
// const addCell = row.createEl('td', ...); 부터
// delBtn.addEventListener('click', ... }); 까지
// 전체 삭제

// 수정된 코드:

// 테이블 헤더 (추가/삭제 컬럼 제거)
headerRow.createEl('th', { text: '#', attr: { style: 'padding: 10px; border: 1px solid var(--background-modifier-border); width: 50px; text-align: center;' } });
headerRow.createEl('th', { text: '한자', attr: { style: 'padding: 10px; border: 1px solid var(--background-modifier-border); width: 80px;' } });
headerRow.createEl('th', { text: '문제', attr: { style: 'padding: 10px; border: 1px solid var(--background-modifier-border);' } });
headerRow.createEl('th', { text: '시간', attr: { style: 'padding: 10px; border: 1px solid var(--background-modifier-border); width: 70px; text-align: center;' } });
headerRow.createEl('th', { text: '결과', attr: { style: 'padding: 10px; border: 1px solid var(--background-modifier-border); width: 80px; text-align: center;' } });
// 추가/삭제 컬럼 제거됨

// tbody 각 행에서도 addCell, delCell 제거
quizRecord.details.forEach((detail, index) => {
    const row = tbody.createEl('tr');
    row.style.cssText = `background: ${detail.isCorrect ? 'rgba(76, 175, 80, 0.05)' : 'rgba(244, 67, 54, 0.05)'};`;

    const numCell = row.createEl('td', { attr: { style: 'padding: 10px; border: 1px solid var(--background-modifier-border); text-align: center; font-weight: 600;' } });
    numCell.textContent = (index + 1).toString();

    const hanziCell = row.createEl('td', { attr: { style: 'padding: 10px; border: 1px solid var(--background-modifier-border); font-weight: 600; font-size: 1.1em;' } });
    hanziCell.textContent = detail.hanzi || '-';

    const questionCell = row.createEl('td', { attr: { style: 'padding: 10px; border: 1px solid var(--background-modifier-border);' } });
    questionCell.textContent = detail.question || '-';

    const timeCell = row.createEl('td', { attr: { style: 'padding: 10px; border: 1px solid var(--background-modifier-border); text-align: center; color: var(--text-muted);' } });
    timeCell.textContent = (detail.timeSpent || 0) + '초';

    const resultCell = row.createEl('td', { attr: { style: 'padding: 10px; border: 1px solid var(--background-modifier-border); text-align: center; font-size: 1.5em;' } });
    resultCell.textContent = detail.isCorrect ? '✅' : '❌';
    
    // 추가/삭제 버튼 제거됨
});

// 불러오기 버튼 개선 - 기록 테이블에 행 클릭 이벤트 추가
// (기존 코드에 이미 있음 - 개선 필요 없음)
